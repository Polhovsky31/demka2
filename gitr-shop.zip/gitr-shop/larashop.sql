-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Мар 07 2023 г., 00:55
-- Версия сервера: 8.0.24
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `larashop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `baskets`
--

CREATE TABLE `baskets` (
  `id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `baskets`
--

INSERT INTO `baskets` (`id`, `created_at`, `updated_at`) VALUES
(212, '2020-11-05 05:47:35', '2020-11-05 05:47:35'),
(216, '2020-11-05 09:16:42', '2020-11-05 09:16:42'),
(218, '2020-11-09 05:37:32', '2020-11-09 08:03:31'),
(219, '2020-11-10 08:49:18', '2020-11-10 08:49:18'),
(220, '2020-11-10 08:49:18', '2020-11-10 08:49:18'),
(221, '2020-11-10 08:49:18', '2020-11-10 08:49:18'),
(222, '2020-11-10 08:49:18', '2020-11-10 08:49:18'),
(223, '2020-11-10 08:49:18', '2020-11-10 08:49:18'),
(224, '2020-11-10 08:49:18', '2020-11-10 08:49:18'),
(225, '2020-11-10 08:49:18', '2020-11-10 08:49:18'),
(226, '2020-11-10 08:49:18', '2020-11-10 08:49:18'),
(227, '2020-11-10 08:49:18', '2020-11-10 08:49:18'),
(228, '2020-11-10 08:49:18', '2020-11-10 08:49:18'),
(229, '2020-11-17 07:44:06', '2020-11-17 07:44:06'),
(230, '2020-11-17 07:44:06', '2020-11-28 12:08:28'),
(231, '2023-03-06 17:56:10', '2023-03-06 17:56:10');

-- --------------------------------------------------------

--
-- Структура таблицы `basket_product`
--

CREATE TABLE `basket_product` (
  `id` bigint UNSIGNED NOT NULL,
  `basket_id` bigint UNSIGNED NOT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `quantity` tinyint UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `basket_product`
--

INSERT INTO `basket_product` (`id`, `basket_id`, `product_id`, `quantity`) VALUES
(56, 230, 58, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `brands`
--

CREATE TABLE `brands` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `brands`
--

INSERT INTO `brands` (`id`, `name`, `content`, `slug`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Первый бренд', 'Чичиков. — Я?.. нет, я уж покажу, — отвечала девчонка. — Куда ж? — сказал Чичиков — А как, например, теперь, — когда были еще только статские советники, сказал даже ошибкою два раза: «ваше.', 'Pervyj-brend', NULL, '2020-10-09 05:20:42', '2020-11-03 09:23:49'),
(2, 'Пятый бренд', 'Повторивши это раза три, он попросил хозяйку приказать заложить его бричку. — Говоря — это, Ноздрев показал пальцем на своем мизинце самую маленькую часть. — Голову.', 'Pyatyj-brend', NULL, '2020-10-09 05:20:42', '2020-11-03 09:25:47'),
(3, 'Второй бренд', 'Ты лучше человеку не будет ли эта негоция — несоответствующею гражданским постановлениям и дальнейшим видам России, а чрез минуту потом прибавил, что казна получит даже выгоды, ибо получит законные.', 'Vtoroj-brend', NULL, '2020-10-09 05:20:42', '2020-11-03 09:24:31'),
(4, 'Третий бренд', 'Чичикову, — я к тебе просьба. — Какая? — Дай прежде слово, что исполнишь. — Да как же цена? хотя, впрочем, это такой предмет… что о — цене даже странно….', 'Tretij-brend', NULL, '2020-10-09 05:20:42', '2020-11-03 09:25:04'),
(5, 'Четвертый бренд', 'Селифану сей же час спросил: «Не побеспокоил ли я вас?» Но Чичиков отказался решительно как играть, так и есть. Я уж сказал, что не угадаешь: штабс-ротмистр Поцелуев.', 'Chetvertyj-brend', NULL, '2020-10-09 05:20:42', '2020-11-03 09:26:37'),
(6, 'Шестой бренд', 'Нет, больше двух рублей я не то, — сказал Манилов, вдруг очнувшись и почти над головами их раздалися крик сидевших в коляске дамы глядели на все согласный Селифан.', 'Shestoj-brend', NULL, '2020-10-09 05:20:42', '2020-11-03 09:27:16'),
(7, 'Седьмой бренд', 'Пока приезжий господин осматривал свою комнату, внесены были его мысли. «Славная бабешка! — сказал он. — Но позвольте — доложить, не будет ли это предприятие или.', 'Sedmoj-brend', NULL, '2020-10-09 05:20:42', '2020-11-03 09:27:45'),
(8, 'Восьмой бренд', 'Дождь стучал звучно по деревянной крыше и журчащими ручьями стекал в подставленную бочку. Между тем три экипажа подкатили уже к чинам генеральским, те, бог весть, может быть, и познакомятся с.', 'Vosmoj-brend', NULL, '2020-10-09 05:20:42', '2020-11-03 09:28:12'),
(9, 'Девятый бренд', 'Что ж тут смешного? — сказал он наконец, высунувшись из брички. — Что, мошенник, по какой дороге ты едешь? — сказал Ноздрев. — Стану я разве.', 'Devyatyj-brend', NULL, '2020-10-09 05:20:42', '2020-11-03 09:28:38'),
(10, 'Десятый бренд', 'Хозяйка очень часто обращалась к Чичикову с словами: «Вы ничего не было. Поехали отыскивать Маниловку. Проехавши две версты, встретили поворот на проселочную дорогу.', 'Desyatyj-brend', NULL, '2020-10-09 05:20:42', '2020-11-03 09:29:35');

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE `categories` (
  `id` bigint UNSIGNED NOT NULL,
  `parent_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `name`, `content`, `slug`, `image`, `created_at`, `updated_at`) VALUES
(1, 0, 'Струнные', 'непонятные веши которые издают непонятные звуки', 'stun', '', '2020-10-09 05:20:41', '2020-11-03 06:10:56'),
(2, 0, 'Клавишные', 'что то хотел добавить но, не добавил', 'klavishi', 'sA7vDIfsYGiMzlGMA5T4q9aP95JxHuz9SKFeK1Hn.jpeg', '2020-10-09 05:20:41', '2020-11-03 06:16:53'),
(3, 0, 'И ещё одни', 'что то хотел добавить но, не добавил', 'more', 'iR5N3SgGf7Qpy5BhK9LtqMmeX0tje2TF9SLNjCvi.jpeg', '2020-10-09 05:20:41', '2020-11-28 12:10:58'),
(5, 1, '2x струнные', 'штуки у которых только 2 струны, логично (-_-)', '2srun', 'SWvVfQ6iCtgytrZNZAXqicpjHqGf1ImYdqLy2Cv7.jpeg', '2020-10-09 05:20:41', '2020-11-03 06:11:41'),
(6, 1, '3x струнные', 'штуки у которых только 3 струны, логично (-_-)', '3strun', 'FUPxQ5ExFKj55ugHp1rWDyJYPrHYycunXlEfNZFU.jpeg', '2020-10-09 05:20:41', '2020-11-03 06:13:40'),
(7, 2, 'Черно-белые клавиши', 'как зебра', 'zebr', '5gEitEAOgCk3zr9H1NRQNNwHiGDR4hlK15fE22pN.jpeg', '2020-10-09 05:20:41', '2020-11-03 06:21:40'),
(9, 3, 'Мужские сумки', 'После таких сильных — убеждений Чичиков почти уже не было вместо швейцаров лихих собак, которые доложили о нем так звонко, что он любезнейший и обходительнейший человек. Даже сам Собакевич.', 'Muzhskie-sumki', 'vZRjzR7y75reTO3c4ANRCy91rRuU7AzAhG69QiL1.jpeg', '2020-10-09 05:20:41', '2020-11-28 12:01:20'),
(14, 2, 'Бело-черные клавиши', 'как зебра, но наоборот', 'zebb', 'kEIZrVvDUkdFyiqYmy83tegdjzwlzK8rdbfDiXV9.jpeg', '2020-11-03 06:05:49', '2020-11-28 11:54:05'),
(19, 3, 'Женские сумки', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab ad alias, aliquam blanditiis debitis delectus deserunt dicta dolorem ea expedita itaque laboriosam minima, modi neque perspiciatis providen', 'Zhenskie-sumki', 'kdJPeOYsYii9k754SbMthRMfLHaddaAgzD2Q3oOg.jpeg', '2020-11-03 06:10:21', '2020-11-28 12:04:00');

-- --------------------------------------------------------

--
-- Структура таблицы `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_09_28_130327_create_categories_table', 1),
(5, '2020_09_28_130335_create_brands_table', 1),
(6, '2020_09_28_130346_create_products_table', 1),
(7, '2020_10_02_120033_create_baskets_table', 1),
(8, '2020_10_02_120730_create_basket_product_table', 1),
(9, '2020_10_09_081701_alter_users_table', 1),
(16, '2020_10_10_105603_create_orders_table', 2),
(17, '2020_10_10_111729_create_order_items_table', 2),
(18, '2020_10_25_090836_alter_orders_table', 3),
(20, '2020_10_27_060337_create_pages_table', 4),
(24, '2020_11_01_064359_create_profiles_table', 5),
(25, '2020_11_08_101100_alter_products_table', 6),
(26, '2020_11_10_111203_create_items_table', 7);

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(10,2) UNSIGNED NOT NULL,
  `status` tinyint UNSIGNED NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `name`, `email`, `phone`, `address`, `comment`, `amount`, `status`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Андрей Сергеев', 'sergeev.a@mail.ru', '+7 (495) 777-77-77', 'Москва, 3-й Лихачевский переулок, д.1, к.1, кв. 22', NULL, '9868.00', 4, '2020-10-11 05:20:41', '2020-10-25 07:10:15'),
(2, NULL, 'Константин Антонов', 'antonov.k@gmail.com', '+7 (495) 555-55-55', 'Москва, Флотская 5, кв.25', NULL, '9868.00', 4, '2020-10-11 06:46:00', '2020-10-25 07:11:24'),
(3, NULL, 'Евгений Токмаков', 'tokmakov.e@mail.ru', '+7 (495) 111-11-11', 'Москва, Чехова 11, кв. 9', 'Какой-то комментарий от покупателя', '4729.00', 4, '2020-10-11 08:42:08', '2020-10-25 07:11:52'),
(4, NULL, 'Дмитрий Николаев', 'nikolaev.d@mail.ru', '+7 (495) 222-22-22', 'Москва, улица Лавочкина, дом 5, кв. 17', 'Какой-то комментарий от покупателя', '15349.00', 4, '2020-10-11 08:45:00', '2020-10-25 07:12:22'),
(5, NULL, 'Евгений Федоров', 'fedorov.e@mail.ru', '+7 (926) 123-45-67', '125438, Москва, ул. Строителей, дом 123, кв. 456', 'Какой-то коментарий к заказу от покупателя', '4729.00', 3, '2020-10-11 09:21:03', '2020-10-25 07:12:42'),
(6, NULL, 'Николай Петров', 'petrov.n@gmail.com', '+7 (495) 333-33-33', 'Москва, Коптевская 12, кв. 43', 'Какой-то комментарий', '3317.00', 2, '2020-10-11 09:32:01', '2020-10-25 07:13:02'),
(7, 2, 'Евгений Токмаков', 'tokmakov.e@mail.ru', '+7 (495) 444-44-44', 'Онежская, дом 17, кв.32', 'Какой-то комментарий', '4895.00', 1, '2020-10-12 04:25:50', '2020-10-25 07:13:22'),
(8, NULL, 'Сергей Иванов', 'ivanov.s@mail.ru', '+7 (926) 765-43-21', 'Москва, Шоссе Энтузиастов, дом 5, кв. 11', 'Доставка в воскресенье', '8046.00', 1, '2020-10-25 03:17:42', '2020-11-12 06:31:37'),
(9, 2, 'Евгений  Токмаков', 'tokmakov.e@mail.ru', '+7 (926) 111-11-11', '125438, Москва, Онежская улица, дом 123, кв. 456', 'Доставка в выходные дни', '4331.00', 0, '2020-11-09 07:52:03', '2020-11-09 07:52:03'),
(10, 2, 'Евгений Токмаков', 'tokmakov.e@mail.ru', '+7 (926) 111-11-11', '111141, Москва, 3-й проезд Перова поля, дом 8, стр.11', 'Доставка в будние дни', '10200.00', 0, '2020-11-09 08:03:31', '2020-11-09 08:03:31');

-- --------------------------------------------------------

--
-- Структура таблицы `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint UNSIGNED NOT NULL,
  `order_id` bigint UNSIGNED NOT NULL,
  `product_id` bigint UNSIGNED DEFAULT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(10,2) UNSIGNED NOT NULL,
  `quantity` tinyint UNSIGNED NOT NULL DEFAULT '1',
  `cost` decimal(10,2) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `name`, `price`, `quantity`, `cost`) VALUES
(1, 1, NULL, 'Пока приезжий господин жил в городе, там вам.', '1412.00', 2, '2824.00'),
(2, 1, NULL, 'Манилов посмотрел на него — вдруг.', '1905.00', 3, '5715.00'),
(3, 1, NULL, 'Уже стул, которым он вместе обедал у.', '1329.00', 1, '1329.00'),
(4, 2, NULL, 'Пока приезжий господин жил в городе, там вам.', '1412.00', 2, '2824.00'),
(5, 2, NULL, 'Манилов посмотрел на него — вдруг.', '1905.00', 3, '5715.00'),
(6, 2, NULL, 'Уже стул, которым он вместе обедал у.', '1329.00', 1, '1329.00'),
(7, 3, NULL, 'Пока приезжий господин жил в городе, там вам.', '1412.00', 2, '2824.00'),
(8, 3, NULL, 'Манилов посмотрел на него — вдруг.', '1905.00', 1, '1905.00'),
(9, 4, NULL, 'Вы были замешаны в историю, по случаю.', '1535.00', 4, '6140.00'),
(10, 4, NULL, 'Уже стул, которым он вместе обедал у.', '1329.00', 3, '3987.00'),
(11, 4, NULL, 'Манилов посмотрел на него — вдруг.', '1905.00', 2, '3810.00'),
(12, 4, NULL, 'Пока приезжий господин жил в городе, там вам.', '1412.00', 1, '1412.00'),
(13, 5, NULL, 'Пока приезжий господин жил в городе, там вам.', '1412.00', 2, '2824.00'),
(14, 5, NULL, 'Манилов посмотрел на него — вдруг.', '1905.00', 1, '1905.00'),
(15, 6, 1, 'Пока приезжий господин жил в городе, там вам.', '1412.00', 1, '1412.00'),
(16, 6, 7, 'Манилов посмотрел на него — вдруг.', '1905.00', 1, '1905.00'),
(17, 7, 5, 'Между крепкими греками, неизвестно каким.', '1957.00', 1, '1957.00'),
(18, 7, 12, 'Поцелуев — вместе с исподним и прежде.', '1215.00', 1, '1215.00'),
(19, 7, 16, 'Фетюк, просто фетюк! Засим вошли они в.', '1723.00', 1, '1723.00'),
(20, 8, 1, 'Пока приезжий господин жил в городе, там вам.', '1412.00', 3, '4236.00'),
(21, 8, 7, 'Манилов посмотрел на него — вдруг.', '1905.00', 2, '3810.00'),
(22, 9, 1, 'Мужская зимняя куртка 1', '1412.00', 1, '1412.00'),
(23, 9, 2, 'Мужская зимняя куртка 2', '1300.00', 1, '1300.00'),
(24, 9, 3, 'Мужская зимняя куртка 3', '1619.00', 1, '1619.00'),
(25, 10, NULL, 'Мужские зимние ботинки 1', '1200.00', 1, '1200.00'),
(26, 10, NULL, 'Мужские зимние ботинки 2', '1500.00', 2, '3000.00'),
(27, 10, NULL, 'Мужские зимние ботинки 3', '2000.00', 3, '6000.00');

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

CREATE TABLE `pages` (
  `id` bigint UNSIGNED NOT NULL,
  `parent_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `parent_id`, `name`, `content`, `slug`, `created_at`, `updated_at`) VALUES
(1, 0, 'Доставка', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad animi assumenda, consectetur deserunt distinctio et excepturi iste neque numquam quam quia quidem reiciendis, similique totam voluptate! Aperiam asperiores dignissimos dolorum eaque natus non porro quae veniam. Architecto at aut, debitis ea eum exercitationem ipsam, laudantium minus modi nesciunt nihil obcaecati quia quibusdam quisquam repellat rerum sapiente sed sequi sint ullam.</p><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad animi assumenda, consectetur deserunt distinctio et excepturi iste neque numquam quam quia quidem reiciendis, similique totam voluptate! Aperiam asperiores dignissimos dolorum eaque natus non porro quae veniam. Architecto at aut, debitis ea eum exercitationem ipsam, laudantium minus modi nesciunt nihil obcaecati quia quibusdam quisquam repellat rerum sapiente sed sequi sint ullam.</p>', 'Dostavka', '2020-11-01 03:56:45', '2020-11-26 11:43:49'),
(2, 0, 'Оплата', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad animi assumenda, consectetur deserunt distinctio et excepturi iste neque numquam quam quia quidem reiciendis, similique totam voluptate! Aperiam asperiores dignissimos dolorum eaque natus non porro quae veniam. Architecto at aut, debitis ea eum exercitationem ipsam, laudantium minus modi nesciunt nihil obcaecati quia quibusdam quisquam repellat rerum sapiente sed sequi sint ullam.</p><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad animi assumenda, consectetur deserunt distinctio et excepturi iste neque numquam quam quia quidem reiciendis, similique totam voluptate! Aperiam asperiores dignissimos dolorum eaque natus non porro quae veniam. Architecto at aut, debitis ea eum exercitationem ipsam, laudantium minus modi nesciunt nihil obcaecati quia quibusdam quisquam repellat rerum sapiente sed sequi sint ullam.</p>', 'Oplata', '2020-11-01 03:57:18', '2020-11-01 03:57:18'),
(3, 0, 'Контакты', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad animi assumenda, consectetur deserunt distinctio et excepturi iste neque numquam quam quia quidem reiciendis, similique totam voluptate! Aperiam asperiores dignissimos dolorum eaque natus non porro quae veniam. Architecto at aut, debitis ea eum exercitationem ipsam, laudantium minus modi nesciunt nihil obcaecati quia quibusdam quisquam repellat rerum sapiente sed sequi sint ullam.</p><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad animi assumenda, consectetur deserunt distinctio et excepturi iste neque numquam quam quia quidem reiciendis, similique totam voluptate! Aperiam asperiores dignissimos dolorum eaque natus non porro quae veniam. Architecto at aut, debitis ea eum exercitationem ipsam, laudantium minus modi nesciunt nihil obcaecati quia quibusdam quisquam repellat rerum sapiente sed sequi sint ullam.</p>', 'Kontakty', '2020-11-01 03:57:47', '2020-11-01 03:57:47');

-- --------------------------------------------------------

--
-- Структура таблицы `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` bigint UNSIGNED NOT NULL,
  `category_id` bigint UNSIGNED DEFAULT NULL,
  `brand_id` bigint UNSIGNED DEFAULT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(10,2) UNSIGNED NOT NULL DEFAULT '0.00',
  `sale` tinyint(1) NOT NULL DEFAULT '0',
  `hit` tinyint(1) NOT NULL DEFAULT '0',
  `new` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `category_id`, `brand_id`, `name`, `content`, `slug`, `image`, `price`, `sale`, `hit`, `new`, `created_at`, `updated_at`) VALUES
(1, NULL, 2, 'Гитара черная', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A ab amet asperiores autem cum cumque deserunt dignissimos error exercitationem fuga fugiat illum inventore ipsum libero minus modi molestias nisi placeat, porro praesentium provident quae quam quidem ratione, sed sit unde voluptatem! Dolore expedita iure magni? Aut autem blanditiis dicta eius exercitationem explicabo illo ipsum iste, magni odit placeat quae quaerat quis reprehenderit veritatis. Alias, asperiores corporis culpa delectus est expedita, incidunt labore libero nulla officia perferendis perspiciatis provident quae repellat.', 'Muzhskaya-zimnyaya-kurtka-1', 'oiFl1Q67NjqZwFmx56RTNoOOBBef41m8yhb02vC9.jpeg', '1412.00', 0, 0, 1, '2020-10-09 05:20:42', '2020-11-28 11:37:40'),
(2, NULL, 5, 'Гитара черная 2х струнная', 'трынь', 'Muzhskaya-zimnyaya-kurtka-2', 'JzZShPuDFj28j29rFi3kYjEni4P1xQuCVKwv6KMJ.jpeg', '1300.00', 0, 1, 0, '2020-10-09 05:20:42', '2020-11-09 04:41:20'),
(3, NULL, 5, 'Гитара из ада', 'Он был недоволен поведением Собакевича. Все-таки, как бы с тем, у которого все до последнего выказываются белые, как сахар, зубы, дрожат и прыгают щеки, а сосед за двумя дверями, в третьей комнате, вскидывается со сна, вытаращив очи и произнося: «Эк его неугомонный бес как обуял!» — подумал про себя Чичиков, — сказал Чичиков, — сказал с приятною улыбкою Манилов. Наконец оба приятеля вошли в дверь.', 'Muzhskaya-zimnyaya-kurtka-3', 'xEHphc1qaMrNxDRmKZmqojzIJJ20i3sMTDF39HQv.jpeg', '1619.00', 1, 0, 0, '2020-10-09 05:20:42', '2020-11-09 04:41:38'),
(4, NULL, 1, 'Струная шляпа', 'Селифан, не видя так долго заниматься Коробочкой? Коробочка ли, Манилова ли, хозяйственная ли жизнь, или нехозяйственная — мимо их! Не то на свете дивно устроено: веселое мигом обратится в печальное, если только она держалась на ту пору вместо Чичикова какой-нибудь двадцатилетний юноша, гусар ли он, или просто благовидные, весьма гладко выбритые овалы лиц, так же красным, как самовар, так что скорей место затрещит и угнется под ними, а уж они не двигались и стояли как вкопанные.', 'Muzhskaya-zimnyaya-kurtka-4', 'nTsbhPgg3EZnTVgj31LT4nrk9gzd4PAGeSjYEOyI.jpeg', '1452.00', 0, 0, 1, '2020-10-09 05:20:42', '2020-11-09 04:41:54'),
(5, NULL, 3, 'Электропианино', 'Вся разница в том, что делается в ее доме и в деревне остались только старые бабы да малые ребята. Постромки отвязали; несколько тычков чубарому коню так понравилось новое знакомство, что он начал — называть их наконец секретарями. Между тем псы заливались всеми возможными голосами: один, забросивши вверх голову, выводил так протяжно и с русским желудком — сладят! Нет, это все готовится? вы есть не так густ, как другой. — А свиного сала не покупаете? — сказала.', 'Muzhskaya-zimnyaya-kurtka-5', '0FEplLfCTM6cmrtkbnHIgg1Jv9nKti00usiTnwS6.jpeg', '1957.00', 0, 1, 0, '2020-10-09 05:20:42', '2020-11-09 04:42:12'),
(6, NULL, 3, 'Электропианино', 'Анну, и поговаривали даже, что был представлен к звезде; впрочем, был большой добряк и даже бузиной, подлец, затирает; но — за ушами пальцем. — Очень обходительный и приятный человек, — отвечал Ноздрев — Нет, в женском поле не нуждаюсь. — Ну, как ты себе хочешь, а не в первый раз в дороге. Чемодан внесли кучер Селифан, низенький человек в решительные минуты найдется, что сделать, не вдаваясь в дальние рассуждения, то, поворотивши направо, на первую перекрестную дорогу.', 'Muzhskaya-zimnyaya-kurtka-6', 'BFIJ5EvymTAyHrbVnlQY7KjGnfByyAgWbo25dBtd.jpeg', '1835.00', 1, 0, 0, '2020-10-09 05:20:42', '2020-11-09 04:42:35'),
(7, NULL, 1, 'Струная шляпа 2', 'Я знаю, что выиграю, да мне нужно. — За водочку, барин, не заплатили… — сказала — хозяйка, когда они вышли на крыльцо. — Будет, будет готова. Расскажите только мне, как добраться до большой — дороги. — Как с того времени много у вас был пожар, матушка? — Плохо, отец мой. — Как вы себе хотите, я покупаю не для просьб. Впрочем, чтобы успокоить ее, он дал ей какой-то лист в рубль ценою. Написавши письмо, дал он ей подписаться и попросил маленький списочек мужиков.', 'Muzhskaya-zimnyaya-kurtka-7', 'mkMMlxiTgyyhps1jDxndaRiqrv9DwHl58QVYf21b.jpeg', '1905.00', 0, 0, 1, '2020-10-09 05:20:42', '2020-11-09 04:42:54'),
(8, NULL, 4, 'электрогитара', 'Такой гадкий привиделся; а рога-то длиннее бычачьих. — Я его нарочно кормлю сырым мясом. Мне хочется, чтобы он был человек видный; черты лица больше закругленные и крепкие. Это были почетные чиновники в городе. Увы! толстые умеют лучше на этом свете обделывать дела свои, нежели тоненькие. Тоненькие служат больше по особенным поручениям или только числятся и виляют туда и сюда; их существование как-то слишком легко, воздушно и совсем неожиданным образом. Все, не.', 'Zhenskaya-zimnyaya-kurtka-1', 'u8gZMStLlawrim349cssiXTSdc2jxzytePnKydGI.jpeg', '1252.00', 0, 1, 0, '2020-10-09 05:20:42', '2020-11-09 04:43:12'),
(9, NULL, 3, 'электрогитара', 'Так и блондинка тоже вдруг совершенно неожиданным образом показалась в нашей поэме. Лицо Ноздрева, верно, уже сколько-нибудь знакомо читателю. Таких людей приходилось всякому встречать немало. Они называются разбитными малыми, слывут еще в детстве и в другом кафтане; но легкомысленно непроницательны люди, и человек в то время, когда молчал, — может быть, а не подоспей капитан-исправник, мне бы, может быть, около.', 'Zhenskaya-zimnyaya-kurtka-2', 'blzxUpja1u6XYCoixIyubJ1YUUGYOCkC8s5C48fN.jpeg', '1254.00', 1, 0, 0, '2020-10-09 05:20:42', '2020-11-09 04:43:40'),
(10, NULL, 4, 'электрогитара', 'Потом показались трубки — деревянные, глиняные, пенковые, обкуренные и необкуренные, обтянутые замшею и необтянутые, чубук с трубкою в зубах. Ноздрев приветствовал его по-дружески и даже незнакомым; шестой уже одарен такою рукою, которая чувствует желание сверхъестественное заломить угол какому-нибудь бубновому тузу или двойке, тогда как рука седьмого так и быть, в шашки сыграю. — Души идут в ста рублях! — Зачем же? довольно, если пойдут в пятидесяти. — Нет, брат, это.', 'Zhenskaya-zimnyaya-kurtka-3', 'rPiPOPVOGP3DUz24BwZG7u1zXu6GmuMxl0sphlvp.jpeg', '1535.00', 0, 0, 0, '2020-10-09 05:20:42', '2020-11-03 07:01:27'),
(11, NULL, 4, 'электрогитара', 'Под всем этим было написано: «И вот заведение». Кое-где просто на улице стояли столы с орехами, мылом и пряниками, похожими на искусственные, и самый — крап глядел весьма подозрительно. — Отчего ж не сорвал, — сказал тихо Чичиков Ноздреву. — А ваше имя как? — спросила помещица. — Ведь я на обывательских приехал! — Вот на этом свете обделывать дела свои, нежели тоненькие. Тоненькие служат больше по особенным поручениям или.', 'Zhenskaya-zimnyaya-kurtka-4', '8DNE0B7lCIZQmycJRiaDYVpv9Bjhdmxnq7pB0yTv.jpeg', '1534.00', 0, 0, 0, '2020-10-09 05:20:42', '2020-11-03 07:02:15'),
(12, NULL, 1, 'Струная шляпа 3', 'Прошу покорнейше, — сказал Чичиков, изумленный таким обильным — наводнением речей, которым, казалось, и конца не — знакомы? Зять мой Мижуев! Мы с Кувшинниковым каждый день завтракали в его голове: как ни переворачивал он ее, но никак не была похожа на неприступную. Напротив, — крепость чувствовала такой страх, что душа ее спряталась в самые губы, так что возвращался домой он иногда с одной только бакенбардой, и то же самое время подвинул обшлагом рукава и другую — комнату, и.', 'Zhenskaya-zimnyaya-kurtka-5', 'fOvrgGngD5NbdXFivOeEBnbWIUk8GMgoUksCHaRJ.jpeg', '1215.00', 0, 0, 0, '2020-10-09 05:20:42', '2020-11-03 07:02:58'),
(13, NULL, 2, 'Орган', 'Расспросивши подробно будочника, куда можно пройти ближе, если понадобится, к собору, к присутственным местам, к губернатору, он отправился взглянуть на реку, протекавшую посредине города, дорогою оторвал прибитую к столбу афишу, с тем только, чтобы увидеться с образованными людьми. Одичаешь, — знаете, будешь все время жить взаперти. — Правда, с такой дороги и очень нужно отдохнуть. Вот здесь и — Фемистоклюса, которые занимались каким-то деревянным.', 'Zhenskie-zimnie-sapogi-1', 'HMgblgXw4l61wlumssDM33zsxmlLFahGAR1tBHNC.jpeg', '1329.00', 0, 0, 0, '2020-10-09 05:20:42', '2020-11-03 07:16:43'),
(14, NULL, 3, 'электрогитара', 'К чему же об заклад? — Ну, бог с ним! — Ну, семнадцать бутылок ты не хочешь? — Не сорвал потому, что загнул утку не вовремя. А ты думаешь, доедет то колесо, если б один самовар не был сопровожден ничем особенным; только два русские мужика, стоявшие у дверей кабака против гостиницы, сделали кое-какие замечания, относившиеся, впрочем, более к экипажу, чем к сидевшему в нем. «Вишь ты, — сказал Ноздрев, немного помолчавши. — Не знаю, как вам.', 'Zhenskie-zimnie-sapogi-2', 'W5jOV9eNytr7Wrc43Lf65l4xXt0BCKELjHF7C7zC.jpeg', '1881.00', 0, 0, 0, '2020-10-09 05:20:42', '2020-11-03 07:17:54'),
(15, NULL, 1, 'Струная шляпа 4', 'Пропал бы, как волдырь на воде, без всякого следа, не оставивши потомков, не доставив будущим детям ни состояния, ни честного имени!» Герой наш очень заботился о своих потомках. «Экой скверный барин! — думал про себя Чичиков, садясь. в бричку. — Послушай, Чичиков, ты должен кормить, потому что он, точно, хотел бы — можно сказать, меня самого обижаешь, она такая почтенная и верная! Услуги оказывает такие… — поверишь, у меня видел, возьму я с тобою нет возможности играть.', 'Zhenskie-zimnie-sapogi-3', 'q0lmvX6YXq2gabOhgi9GGYKrLeWa8oBwPu7c9hue.jpeg', '1204.00', 0, 0, 0, '2020-10-09 05:20:42', '2020-11-03 07:18:40'),
(16, NULL, 2, 'Синтезатор', 'И в самом деле, — подумал про себя Чичиков, садясь. в бричку. — Говоря — это, Ноздрев показал пустые стойла, где были прежде тоже хорошие лошади. В этой конурке он приладил к стене узенькую трехногую кровать, накрыв ее небольшим подобием тюфяка, убитым и тоненьким, как лепешка. Кроме страсти к чтению, он имел случай заметить, что это сущее ничего, что он, чувствуя уважение личное к нему, готов бы даже воспитали тебя по моде, другие оделись во что бог послал в.', 'Zhenskie-zimnie-sapogi-4', '732UpfqS2NrufG6AUFuSxUZUleCGfO3egAqButg1.jpeg', '1723.00', 0, 0, 0, '2020-10-09 05:20:42', '2020-11-03 07:19:56'),
(17, NULL, 3, 'электрогитара', 'Селифан, Чичиков, гладь и пустота окрестных полей. Везде, где бы ни случилось с ним; но судьбам угодно было спасти бока, — плеча и все что хочешь. Эх, Чичиков, ну что он намерен с ним поговорить об одном очень нужном деле. — В таком случае позвольте мне быть откровенным: я бы с тем, который бы хотя одним чином был его повыше, и шапочное знакомство с графом или князем для него лучше всяких тесных дружеских отношений. Автор даже опасается за своего.', 'Zhenskie-zimnie-sapogi-5', 'Eb3QrSkfwXcNEWwprxZNrulpCCaI6ZvD1oWZEOoQ.jpeg', '1196.00', 0, 0, 0, '2020-10-09 05:20:42', '2020-11-03 07:20:45'),
(18, NULL, 2, 'Пианино', 'Фемистоклюс, жуя хлеб и болтая головой направо и налево. Чичиков поблагодарил хозяйку, сказавши, что ему сделать, но ничего другого не мог — понять, как губернатор мог попасть в разбойники. — Признаюсь, этого — я бы мог сорвать весь банк. — Однако ж это обидно! что же я такое в самом деле были уже мертвые, а потом отправляющиеся в Карлсбад или на дверь. — Не сделал привычки, боюсь; говорят, трубка сушит. — Позвольте мне вас попотчевать трубочкою. — Нет, брат, это, кажется, ты сочинитель, да.', 'Zhenskie-zimnie-sapogi-6', 'IhHVbOoqc1sjh0gpINFDKEwOTaPZfIbmX5a99mRr.jpeg', '1997.00', 0, 0, 0, '2020-10-09 05:20:42', '2020-11-03 07:27:50'),
(19, NULL, 1, 'Струная шляпа 5', 'Казалось, как будто несколько знакомо. Он стал припоминать себе: кто бы это сделать? — сказала супруга Собакевича. — А вы еще не вычеркнуть из ревизии? — Ну да мне нужно. — Ну ее, жену, к..! важное в самом деле, — подумал про себя Чичиков и тут же, пред вашими глазами, и нагадит вам. И нагадит так, как есть, в том же месте, одинаково держат голову, их почти готов принять за мебель и думаешь, что скроешь свое.', 'Zhenskie-zimnie-sapogi-7', '5DlHLq11xQU1cgh4r48vsAkNmDeAarIvVIq3hnJ8.jpeg', '1425.00', 0, 0, 0, '2020-10-09 05:20:42', '2020-11-03 07:28:35'),
(20, NULL, 3, 'Женские летние туфли 1', 'Ну, да изволь, я готова отдать за пятнадцать верст, то значит, что к нему в шкатулку. И в самом деле дело станете делать вместе! — Не — хочешь быть посланником? — Хочу, — отвечал Фемистоклюс, жуя хлеб и болтая головой направо и налево, и зятю и Чичикову; Чичиков заметил, что придумал не очень ловко и предлог довольно слаб. — Ну, да уж оттого! — сказал Чичиков, изумленный в самом деле какой-нибудь — прок? — Нет.', 'Zhenskie-letnie-tufli-1', 'ORXURHGdSv84PGFTf8JIqycI5oexu5IoaJmcmz5b.jpeg', '1930.00', 0, 0, 0, '2020-10-09 05:20:42', '2020-11-03 07:29:39'),
(22, NULL, 3, 'электрогитара', 'Богдан ни в чем состоит предмет. Я полагаю даже, — что он спорил, а между тем про себя Чичиков и в Петербург, и на ярмарке посчастливилось напасть на простака и обыграть его, он накупал кучу всего, что прежде хозяйственная часть, то есть книг или бумаги; висели только сабли и два ружья — одно только и останавливает, что ведь они уже мертвые. «Эк ее, дубинноголовая какая! — сказал Ноздрей. — Давай его, клади сюда на пол!.', 'Zhenskie-letnie-tufli-3', 'ZIjOibdHRYzrPrY5mxCwyu6Ytjnws2lKhimZGED6.jpeg', '1311.00', 0, 0, 0, '2020-10-09 05:20:42', '2020-11-03 07:31:43'),
(24, NULL, 4, ' Не электрогитара', 'Манилова, делал весьма дельные замечания чубарому пристяжному коню, запряженному с правой стороны, а дядя Митяй с рыжей бородой взобрался на коренного коня и сделался похожим на средней величины медведя. Для довершение сходства фрак на нем не было видно такого, напротив, лицо даже казалось степеннее обыкновенного; потом подумал, не спятил ли гость как-нибудь невзначай с ума, и со сметаною? — С хреном и со вкусом хозяина. Зодчий был педант и хотел заплатить этим хозяину за хорошее.', 'Zhenskie-letnie-tufli-5', 'tdqGDPb0rPRT5oP9UyKnrf1M4VO7yG62RQotzyA5.jpeg', '1770.00', 0, 0, 0, '2020-10-09 05:20:42', '2020-11-03 07:33:17'),
(25, NULL, 3, ' Не электрогитара', 'Насилу дотащили, проклятые, я уже перелез вот в — кармане, — продолжал он, обратившись тут же просадил их. — Ну, да изволь, я готова отдать за пятнадцать ассигнацией! Только — смотри, отец мой, а насчет подрядов-то: если случится муки брать — ржаной, или гречневой, или круп, или скотины битой, так уж, — пожалуйста, не затрудняйтесь. Пожалуйста, — проходите, — говорил он, куря трубку, и ему даже один раз «вы». Кучер, услышав, что нужно пропустить два.', 'Zhenskie-letnie-tufli-6', 'oqXN4XYPa19obD66NjOrAGK3eP2j3dHjxOPoILRy.jpeg', '1957.00', 0, 0, 0, '2020-10-09 05:20:42', '2020-11-03 07:34:04'),
(26, NULL, 4, ' Не электрогитара', 'Одних балаганов, я думаю, уже заметил, что это, точно, правда. Уж совсем ни на что не охотник. — Да зачем же приобретать — вещь, решительно для меня ненужную? — Ну вот уж здесь, — сказал Собакевич, оборотившись. — Готова? Пожалуйте ее сюда! — Он и одной не — стоит. — Ей-богу, товар такой странный, совсем небывалый! Здесь Чичиков закусил губу и не изотрется само собою: бережлива старушка, и салопу суждено пролежать долго в.', 'Zhenskie-letnie-tufli-7', 'e8tdDL3fEJpuFW6yRC7rjJ6VIS5PcDno34d5gfk5.jpeg', '1251.00', 0, 0, 0, '2020-10-09 05:20:42', '2020-11-03 07:34:51'),
(29, NULL, 4, 'Электропианино', 'Это бы скорей походило на диво, если бы вы с ним о деле, поступил неосторожно, как ребенок, как дурак: ибо дело совсем не было ни цепочки, ни — часов. Ему даже показалось, что и — прокрутил, канальство, еще сверх шесть целковых. А какой, если б случилось, в Москву или не хотите понимать слов моих, или — вступления в какие-нибудь выгодные обязательства. «Вишь, куды метит, подлец!» — но, однако ж, остановил, впрочем, — они остановились бы и другое слово, да — пропади и околей со всей.', 'Muzhskaya-letnyaya-futbolka-3', 'DkrcUqtXou4NXu4ISvLh5fLYANl9OlXbf6CItdY3.jpeg', '1953.00', 0, 0, 0, '2020-10-09 05:20:42', '2020-11-03 07:43:11'),
(31, NULL, 5, 'Электропианино', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque ducimus, eligendi exercitationem expedita, iure iusto laborum magnam qui quidem repellat similique tempora tempore ullam! Deserunt doloremque impedit quis repudiandae voluptas.', 'Muzhskaya-letnyaya-futbolka-5', 'rChdV4SATYdeRKTrnk1iAJNXGWVt0AxGOjkedWEE.jpeg', '0.00', 0, 0, 0, '2020-11-03 07:46:43', '2020-11-03 07:46:43'),
(32, NULL, 8, 'Электропианино', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque ducimus, eligendi exercitationem expedita, iure iusto laborum magnam qui quidem repellat similique tempora tempore ullam! Deserunt doloremque impedit quis repudiandae voluptas', 'Muzhskaya-letnyaya-futbolka-6', 'LFyN9N3HA2brgZoebYwpzzNcYDx8nb2P5tt8SSwr.jpeg', '0.00', 0, 0, 0, '2020-11-03 07:47:28', '2020-11-03 07:47:28'),
(33, NULL, 10, 'НЕ Электропианино', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque ducimus, eligendi exercitationem expedita, iure iusto laborum magnam qui quidem repellat similique tempora tempore ullam! Deserunt doloremque impedit quis repudiandae voluptas', 'Muzhskaya-letnyaya-futbolka-7', '4ZtTPMdlEDL2VaLD7CtvXlyOUNeA4fxERK1q9Zti.jpeg', '0.00', 0, 0, 0, '2020-11-03 07:48:14', '2020-11-03 07:48:14'),
(34, NULL, 4, 'НЕ Электропианино', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque ducimus, eligendi exercitationem expedita, iure iusto laborum magnam qui quidem repellat similique tempora tempore ullam! Deserunt doloremque impedit quis repudiandae voluptas', 'Muzhskaya-letnyaya-futbolka-8', 'lfd5w0cW14mtG2h0yjtiTKGekcWr5JQQMBc86KKI.jpeg', '0.00', 0, 0, 0, '2020-11-03 07:48:58', '2020-11-03 07:48:58'),
(36, NULL, 8, 'НЕ Электропианино', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque ducimus, eligendi exercitationem expedita, iure iusto laborum magnam qui quidem repellat similique tempora tempore ullam! Deserunt doloremque impedit quis repudiandae voluptas', 'Muzhskaya-letnyaya-futbolka-10', 'zPpBpi3pt3DmBbCnlp4XRT09dLtQxjqUeSBdt2Jo.jpeg', '0.00', 0, 0, 0, '2020-11-03 07:50:56', '2020-11-03 07:50:56'),
(37, NULL, 8, 'НЕ Электропианино', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque ducimus, eligendi exercitationem expedita, iure iusto laborum magnam qui quidem repellat similique tempora tempore ullam! Deserunt doloremque impedit quis repudiandae voluptas', 'Muzhskaya-letnyaya-futbolka-11', '5vDjt4eeKG4DwY9ZRA5olcJ0TLylyxsIjkkVt6Ku.jpeg', '0.00', 0, 0, 0, '2020-11-03 07:51:48', '2020-11-03 07:51:48'),
(53, NULL, 7, 'Первое ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A ab amet asperiores autem cum cumque deserunt dignissimos error exercitationem fuga fugiat illum inventore ipsum libero minus modi molestias nisi placeat, porro praesentium provident quae quam quidem ratione, sed sit unde voluptatem! Dolore expedita iure magni? Aut autem blanditiis dicta eius exercitationem explicabo illo ipsum iste, magni odit placeat quae quaerat quis reprehenderit veritatis. Alias, asperiores corporis culpa delectus est expedita, incidunt labore libero nulla officia perferendis perspiciatis provident quae repellat.', 'Pervoe-plate', '5rF3tkIWDQ9aXVpYmCtaYJQQRlozH9dABKoEoL36.jpeg', '2000.00', 0, 0, 0, '2020-11-28 11:48:30', '2020-11-28 11:48:30'),
(54, NULL, 3, 'Второе ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A ab amet asperiores autem cum cumque deserunt dignissimos error exercitationem fuga fugiat illum inventore ipsum libero minus modi molestias nisi placeat, porro praesentium provident quae quam quidem ratione, sed sit unde voluptatem! Dolore expedita iure magni? Aut autem blanditiis dicta eius exercitationem explicabo illo ipsum iste, magni odit placeat quae quaerat quis reprehenderit veritatis. Alias, asperiores corporis culpa delectus est expedita, incidunt labore libero nulla officia perferendis perspiciatis provident quae repellat.', 'Vtoroe-plate', '4Y3ac0g5e6XQjVNU3U8CWFLzcbpv2FcY5GxCaJl5.jpeg', '1700.00', 0, 0, 1, '2020-11-28 11:49:20', '2020-11-28 11:49:20'),
(55, NULL, 5, 'Третье платье', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A ab amet asperiores autem cum cumque deserunt dignissimos error exercitationem fuga fugiat illum inventore ipsum libero minus modi molestias nisi placeat, porro praesentium provident quae quam quidem ratione, sed sit unde voluptatem! Dolore expedita iure magni? Aut autem blanditiis dicta eius exercitationem explicabo illo ipsum iste, magni odit placeat quae quaerat quis reprehenderit veritatis. Alias, asperiores corporis culpa delectus est expedita, incidunt labore libero nulla officia perferendis perspiciatis provident quae repellat.', 'Trete-plate', 'LOMBbRMO3P434BpS7W0iLN48aflGg0ErMzncbE3N.jpeg', '1900.00', 1, 0, 0, '2020-11-28 11:50:21', '2020-11-28 11:50:21'),
(56, NULL, 10, 'Четвертое платье', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A ab amet asperiores autem cum cumque deserunt dignissimos error exercitationem fuga fugiat illum inventore ipsum libero minus modi molestias nisi placeat, porro praesentium provident quae quam quidem ratione, sed sit unde voluptatem! Dolore expedita iure magni? Aut autem blanditiis dicta eius exercitationem explicabo illo ipsum iste, magni odit placeat quae quaerat quis reprehenderit veritatis. Alias, asperiores corporis culpa delectus est expedita, incidunt labore libero nulla officia perferendis perspiciatis provident quae repellat.', 'Chetvertoe-plate', 'tE3sowShIQwkZKkiQy6Fe7LMc5Jg4FAXXiiLK8vV.jpeg', '1600.00', 0, 0, 0, '2020-11-28 11:51:24', '2020-11-28 11:51:24'),
(57, NULL, 1, 'Пятое ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A ab amet asperiores autem cum cumque deserunt dignissimos error exercitationem fuga fugiat illum inventore ipsum libero minus modi molestias nisi placeat, porro praesentium provident quae quam quidem ratione, sed sit unde voluptatem! Dolore expedita iure magni? Aut autem blanditiis dicta eius exercitationem explicabo illo ipsum iste, magni odit placeat quae quaerat quis reprehenderit veritatis. Alias, asperiores corporis culpa delectus est expedita, incidunt labore libero nulla officia perferendis perspiciatis provident quae repellat.', 'Pyatoe-plate', 'cuME1gN6BmtjaUx5mo3dAe0GpM0b6ML3R2kQcV87.jpeg', '2100.00', 0, 1, 0, '2020-11-28 11:52:08', '2020-11-28 11:52:26'),
(58, NULL, 3, 'Первая юбка', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A ab amet asperiores autem cum cumque deserunt dignissimos error exercitationem fuga fugiat illum inventore ipsum libero minus modi molestias nisi placeat, porro praesentium provident quae quam quidem ratione, sed sit unde voluptatem! Dolore expedita iure magni? Aut autem blanditiis dicta eius exercitationem explicabo illo ipsum iste, magni odit placeat quae quaerat quis reprehenderit veritatis. Alias, asperiores corporis culpa delectus est expedita, incidunt labore libero nulla officia perferendis perspiciatis provident quae repellat.', 'Pervaya-yubka', 'zI3S1DiM1powhfR8YXyz1zTKy9Q2kUpXT8SJfYVX.jpeg', '1750.00', 0, 0, 1, '2020-11-28 11:56:30', '2020-11-28 11:56:30'),
(59, NULL, 6, 'Вторая юбка', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A ab amet asperiores autem cum cumque deserunt dignissimos error exercitationem fuga fugiat illum inventore ipsum libero minus modi molestias nisi placeat, porro praesentium provident quae quam quidem ratione, sed sit unde voluptatem! Dolore expedita iure magni? Aut autem blanditiis dicta eius exercitationem explicabo illo ipsum iste, magni odit placeat quae quaerat quis reprehenderit veritatis. Alias, asperiores corporis culpa delectus est expedita, incidunt labore libero nulla officia perferendis perspiciatis provident quae repellat.', 'Vtoraya-yubka', 'XygSxu7Y2FKGPS8SfSPG1tkmKQtSWELhHDVpyJbU.jpeg', '1850.00', 1, 0, 0, '2020-11-28 11:57:22', '2020-11-28 11:57:22'),
(60, NULL, 8, 'Третья юбка', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A ab amet asperiores autem cum cumque deserunt dignissimos error exercitationem fuga fugiat illum inventore ipsum libero minus modi molestias nisi placeat, porro praesentium provident quae quam quidem ratione, sed sit unde voluptatem! Dolore expedita iure magni? Aut autem blanditiis dicta eius exercitationem explicabo illo ipsum iste, magni odit placeat quae quaerat quis reprehenderit veritatis. Alias, asperiores corporis culpa delectus est expedita, incidunt labore libero nulla officia perferendis perspiciatis provident quae repellat.', 'Tretya-yubka', 'Szv2uVk83zm4koW7TrOrx73alj8rtifPXLCX0Q1p.jpeg', '2150.00', 0, 0, 0, '2020-11-28 11:58:27', '2020-11-28 11:58:27'),
(61, NULL, 2, 'Четвертая юбка', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A ab amet asperiores autem cum cumque deserunt dignissimos error exercitationem fuga fugiat illum inventore ipsum libero minus modi molestias nisi placeat, porro praesentium provident quae quam quidem ratione, sed sit unde voluptatem! Dolore expedita iure magni? Aut autem blanditiis dicta eius exercitationem explicabo illo ipsum iste, magni odit placeat quae quaerat quis reprehenderit veritatis. Alias, asperiores corporis culpa delectus est expedita, incidunt labore libero nulla officia perferendis perspiciatis provident quae repellat.', 'Chetvertaya-yubka', 'f8DPU0QxwILur4XnsVjrFE4gXCybDHndhzhfzhiR.jpeg', '1550.00', 1, 0, 0, '2020-11-28 11:59:31', '2020-11-28 11:59:31'),
(62, NULL, 9, 'Пятая ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A ab amet asperiores autem cum cumque deserunt dignissimos error exercitationem fuga fugiat illum inventore ipsum libero minus modi molestias nisi placeat, porro praesentium provident quae quam quidem ratione, sed sit unde voluptatem! Dolore expedita iure magni? Aut autem blanditiis dicta eius exercitationem explicabo illo ipsum iste, magni odit placeat quae quaerat quis reprehenderit veritatis. Alias, asperiores corporis culpa delectus est expedita, incidunt labore libero nulla officia perferendis perspiciatis provident quae repellat.', 'Pyataya-yubka', '6ZjomZpsO29KPjIDzJBhB50bXoUzLQXDCrpFE1pG.jpeg', '1670.00', 0, 0, 0, '2020-11-28 12:00:15', '2020-11-28 12:00:15'),
(64, 19, 4, ' Не электрогитара', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A ab amet asperiores autem cum cumque deserunt dignissimos error exercitationem fuga fugiat illum inventore ipsum libero minus modi molestias nisi placeat, porro praesentium provident quae quam quidem ratione, sed sit unde voluptatem! Dolore expedita iure magni? Aut autem blanditiis dicta eius exercitationem explicabo illo ipsum iste, magni odit placeat quae quaerat quis reprehenderit veritatis. Alias, asperiores corporis culpa delectus est expedita, incidunt labore libero nulla officia perferendis perspiciatis provident quae repellat.', 'Zhenskaya-sumka-1', 'JSwL7t9bbbeK8SxynUKONjaRgIv7JJUQrTypdp5G.jpeg', '2200.00', 0, 0, 0, '2020-11-28 12:03:27', '2020-11-28 12:03:27');

-- --------------------------------------------------------

--
-- Структура таблицы `profiles`
--

CREATE TABLE `profiles` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `profiles`
--

INSERT INTO `profiles` (`id`, `user_id`, `title`, `name`, `email`, `phone`, `address`, `comment`, `created_at`, `updated_at`) VALUES
(1, 2, 'Доставка домой 2', 'Евгений  Токмаков', 'tokmakov.e@mail.ru', '+7 (926) 111-11-11', '125438, Москва, Онежская улица, дом 15Б, кв. 52', 'Доставка в выходные дни', '2020-11-02 05:29:23', '2020-11-02 11:53:42'),
(2, 2, 'Доставка домой', 'Евгений  Токмаков', 'tokmakov.e@mail.ru', '+7 (926) 111-11-11', '125438, Москва, Онежская улица, дом 123, кв. 456', 'Доставка в выходные дни', '2020-11-02 05:31:26', '2020-11-02 11:31:48'),
(3, 2, 'Доставка на работу', 'Евгений Токмаков', 'tokmakov.e@mail.ru', '+7 (926) 111-11-11', '111141, Москва, 3-й проезд Перова поля, дом 8, стр.11', 'Доставка в будние дни', '2020-11-02 05:53:11', '2020-11-02 11:54:28');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `admin`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Евгений Токмаков', 'tokmakov.e@mail.ru', 1, NULL, '$2y$10$QxlN.XeF/A5Z5lmjKTDhnOiZGjYBIUrwYf7vJSrpo29NDzOX6c4sK', NULL, '2020-10-09 05:24:59', '2020-10-09 05:24:59'),
(2, 'Евгений Токмаков', 'tokmakov-e@yandex.ru', 0, NULL, '$2y$10$5W0/qJpWDt3TPPx0LOdqRudShXIk1KdAwVyEIJpyLUFiI52hVsgdK', NULL, '2020-10-09 11:33:40', '2020-11-01 06:21:24'),
(3, 'Сергей Иванов', 'ivanov.s@mail.ru', 0, NULL, '$2y$10$UsMdWStFTLwhn30mC33RR.V.s4j23Z06U8c5fAryP0Oddu7jTkUK6', NULL, '2020-10-26 11:46:04', '2020-10-26 11:46:04'),
(4, 'Дмитрий Петров', 'petrov.d@mail.ru', 0, NULL, '$2y$10$lAdVpW4zVnaZ0BEaTOi8OOGKokkJVH5CcihgXhMAwhruuZcXuuPEy', NULL, '2020-10-26 11:47:18', '2020-10-26 11:47:18'),
(5, 'Николай Смирнов', 'smirnov.n@gmail.com', 0, NULL, '$2y$10$yvxGq8ZlVIgxa7vjxH4xfuhWFmvPKZ29bagI1uN8hKs7u73Tuw5ra', NULL, '2020-10-26 11:49:18', '2020-11-02 07:16:35'),
(6, 'Андрей Николаев', 'nikolaev.a@gmail.com', 0, NULL, '$2y$10$H6ASTS9bKmx6tS0Oou6zUeB1693IiEUC9axyvwtJTy/x0v9czlG6C', NULL, '2020-10-26 11:50:17', '2020-10-26 11:50:17'),
(7, 'Islam K', '123123@mail.ru', 0, NULL, '$2y$10$mkqN/cdEA66B5FQ9Wq6i6.2OcVRsHKeiuiZTomq0htZyLBl4Cmtx6', NULL, '2023-03-06 18:02:42', '2023-03-06 18:02:42');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `baskets`
--
ALTER TABLE `baskets`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `basket_product`
--
ALTER TABLE `basket_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `basket_product_basket_id_foreign` (`basket_id`),
  ADD KEY `basket_product_product_id_foreign` (`product_id`);

--
-- Индексы таблицы `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `brands_slug_unique` (`slug`);

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`);

--
-- Индексы таблицы `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`);

--
-- Индексы таблицы `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_items_order_id_foreign` (`order_id`),
  ADD KEY `order_items_product_id_foreign` (`product_id`);

--
-- Индексы таблицы `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pages_slug_unique` (`slug`);

--
-- Индексы таблицы `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`(191));

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_slug_unique` (`slug`),
  ADD KEY `products_category_id_foreign` (`category_id`),
  ADD KEY `products_brand_id_foreign` (`brand_id`);

--
-- Индексы таблицы `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `profiles_user_id_foreign` (`user_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`(191));

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `baskets`
--
ALTER TABLE `baskets`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=232;

--
-- AUTO_INCREMENT для таблицы `basket_product`
--
ALTER TABLE `basket_product`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT для таблицы `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT для таблицы `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT для таблицы `pages`
--
ALTER TABLE `pages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT для таблицы `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `basket_product`
--
ALTER TABLE `basket_product`
  ADD CONSTRAINT `basket_product_basket_id_foreign` FOREIGN KEY (`basket_id`) REFERENCES `baskets` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `basket_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Ограничения внешнего ключа таблицы `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL;

--
-- Ограничения внешнего ключа таблицы `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

--
-- Ограничения внешнего ключа таблицы `profiles`
--
ALTER TABLE `profiles`
  ADD CONSTRAINT `profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
