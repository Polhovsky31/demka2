@extends('layout.site', ['title' => $page->name])

@section('content')
    <div><p>СУУУУУП!!!!!!!!!!</p></div>
@endsection
