@extends('layout.site', ['title' => $page->name])

@section('content')
    <div><p>АМЛЕТ</p></div>
@endsection
