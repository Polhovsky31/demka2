<h4>Разделы каталога</h4>
<div id="catalog-sidebar">
    @include('layout.part.branch', ['parent' => 0])
</div>
