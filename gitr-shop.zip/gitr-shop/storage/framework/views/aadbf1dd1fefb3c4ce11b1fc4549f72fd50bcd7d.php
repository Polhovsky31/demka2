<?php $__env->startSection('content'); ?>
    <h1 class="mb-3">Все страницы сайта</h1>
    <a href="<?php echo e(route('admin.page.create')); ?>" class="btn btn-success mb-4">
        Создать страницу
    </a>
    <?php if(count($pages)): ?>
        <table class="table table-bordered">
            <tr>
                <th>#</th>
                <th width="45%">Наименование</th>
                <th width="45%">ЧПУ (англ.)</th>
                <th><i class="fas fa-edit"></i></th>
                <th><i class="fas fa-trash-alt"></i></th>
            </tr>
            <?php echo $__env->make('admin.page.part.tree', ['level' => -1, 'parent' => 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </table>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', ['title' => 'Все страницы сайта'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\gitr-shop\resources\views/admin/page/index.blade.php ENDPATH**/ ?>