<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h1><?php echo e($page->name); ?></h1>
        </div>
        <div class="card-body">
            <?php echo $page->content; ?>

        </div>
        <div class="card-footer">
            Добавлена: <?php echo e($page->created_at->format('d.m.Y H:i')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', ['title' => $page->name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\laravel-7-shop-master\resources\views/page/show.blade.php ENDPATH**/ ?>