<?php $__env->startSection('content'); ?>
    <h1>Панель управления</h1>
    <p>Добро пожаловать, <?php echo e(auth()->user()->name); ?></p>
    <p>Это панель управления для администратора интернет-магазина.</p>
    <form action="<?php echo e(route('user.logout')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-primary">Выйти</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\gitr-shop\resources\views/admin/index.blade.php ENDPATH**/ ?>