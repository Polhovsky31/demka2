<?php $__env->startSection('content'); ?>
    <h1><?php echo e($category->name); ?></h1>
    <ul>
        <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('admin.product.category', ['category' => $child->id])); ?>">
                    <?php echo e($child->name); ?>

                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <a href="<?php echo e(route('admin.product.create')); ?>" class="btn btn-success mb-4">
        Создать товар
    </a>
    <?php if(count($products)): ?>
        <table class="table table-bordered">
            <tr>
                <th width="30%">Наименование</th>
                <th width="65%">Описание</th>
                <th><i class="fas fa-edit"></i></th>
                <th><i class="fas fa-trash-alt"></i></th>
            </tr>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a href="<?php echo e(route('admin.product.show', ['product' => $product->id])); ?>">
                        <?php echo e($product->name); ?>

                    </a>
                </td>
                <td><?php echo e(iconv_substr($product->content, 0, 150)); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.product.edit', ['product' => $product->id])); ?>">
                        <i class="far fa-edit"></i>
                    </a>
                </td>
                <td>
                    <form action="<?php echo e(route('admin.product.destroy', ['product' => $product->id])); ?>"
                          method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="m-0 p-0 border-0 bg-transparent">
                            <i class="far fa-trash-alt text-danger"></i>
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php echo e($products->links()); ?>

    <?php else: ?>
        <p>Нет товаров в этой категории</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', ['title' => 'Товары категории'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\gitr-shop\resources\views/admin/product/category.blade.php ENDPATH**/ ?>