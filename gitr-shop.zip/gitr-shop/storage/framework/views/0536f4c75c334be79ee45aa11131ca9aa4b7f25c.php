<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Все пользователи</h1>

    <table class="table table-bordered">
        <tr>
            <th>#</th>
            <th width="25%">Дата регистрации</th>
            <th width="25%">Имя, фамилия</th>
            <th width="25%">Адрес почты</th>
            <th width="20%">Кол-во заказов</th>
            <th><i class="fas fa-edit"></i></th>
        </tr>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->created_at->format('d.m.Y H:i')); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></td>
                <td><?php echo e($user->orders->count()); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.user.edit', ['user' => $user->id])); ?>">
                        <i class="far fa-edit"></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php echo e($users->links()); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.admin', ['title' => 'Все пользователи'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\openserver\domains\gitr-shop\resources\views/admin/user/index.blade.php ENDPATH**/ ?>