<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Редактирование заказа</h1>
    <form method="post" action="<?php echo e(route('admin.order.update', ['order' => $order->id])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <?php ($status = old('status') ?? $order->status ?? 0); ?>
            <select name="status" class="form-control" title="Статус заказа">
            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>" <?php if($key == $status): ?> selected <?php endif; ?>>
                    <?php echo e($value); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="name" placeholder="Имя, Фамилия"
                   required maxlength="255" value="<?php echo e(old('name') ?? $order->name ?? ''); ?>">
        </div>
        <div class="form-group">
            <input type="email" class="form-control" name="email" placeholder="Адрес почты"
                   required maxlength="255" value="<?php echo e(old('email') ?? $order->email ?? ''); ?>">
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="phone" placeholder="Номер телефона"
                   required maxlength="255" value="<?php echo e(old('phone') ?? $order->phone ?? ''); ?>">
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="address" placeholder="Адрес доставки"
                   required maxlength="255" value="<?php echo e(old('address') ?? $order->address ?? ''); ?>">
        </div>
        <div class="form-group">
            <textarea class="form-control" name="comment" placeholder="Комментарий"
                      maxlength="255" rows="2"><?php echo e(old('comment') ?? $order->comment ?? ''); ?></textarea>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-success">Сохранить</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.admin', ['title' => 'Редактирование заказа'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\openserver\domains\gitr-shop\resources\views/admin/order/edit.blade.php ENDPATH**/ ?>