<?php $__env->startSection('content'); ?>
    <h1>Создание профиля</h1>
    <form method="post" action="<?php echo e(route('user.profile.store')); ?>">
        <?php echo $__env->make('user.profile.part.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', ['title' => 'Создание профиля'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\laravel-7-shop-master\resources\views/user/profile/create.blade.php ENDPATH**/ ?>