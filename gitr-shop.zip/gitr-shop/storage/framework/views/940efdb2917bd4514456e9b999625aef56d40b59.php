<?php $__env->startSection('content'); ?>
    <h1>Все заказы</h1>

    <table class="table table-bordered">
        <tr>
            <th>№</th>
            <th width="18%">Дата и время</th>
            <th width="5%">Статус</th>
            <th width="18%">Покупатель</th>
            <th width="18%">Адрес почты</th>
            <th width="18%">Номер телефона</th>
            <th width="18%">Пользователь</th>
            <th><i class="fas fa-eye"></i></th>
            <th><i class="fas fa-edit"></i></th>
        </tr>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($order->id); ?></td>
                <td><?php echo e($order->created_at->format('d.m.Y H:i')); ?></td>
                <td>
                    <?php if($order->status == 0): ?>
                        <span class="text-danger"><?php echo e($statuses[$order->status]); ?></span>
                    <?php elseif(in_array($order->status, [1,2,3])): ?>
                        <span class="text-success"><?php echo e($statuses[$order->status]); ?></span>
                    <?php else: ?>
                        <?php echo e($statuses[$order->status]); ?>

                    <?php endif; ?>
                </td>
                <td><?php echo e($order->name); ?></td>
                <td><a href="mailto:<?php echo e($order->email); ?>"><?php echo e($order->email); ?></a></td>
                <td><?php echo e($order->phone); ?></td>
                <td>
                    <?php if(isset($order->user)): ?>
                        <?php echo e($order->user->name); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('admin.order.show', ['order' => $order->id])); ?>">
                        <i class="far fa-eye"></i>
                    </a>
                </td>
                <td>
                    <a href="<?php echo e(route('admin.order.edit', ['order' => $order->id])); ?>">
                        <i class="far fa-edit"></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php echo e($orders->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', ['title' => 'Все заказы'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\gitr-shop\resources\views/admin/order/index.blade.php ENDPATH**/ ?>