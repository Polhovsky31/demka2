<?php $__env->startSection('content'); ?>
    <h1>Ваша корзина</h1>
    <?php if(count($products)): ?>
        <form action="<?php echo e(route('basket.clear')); ?>" method="post" class="text-right">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-outline-danger mb-4 mt-0">
                Очистить корзину
            </button>
        </form>
        <table class="table table-bordered">
            <tr>
                <th>№</th>
                <th>Наименование</th>
                <th>Цена</th>
                <th>Кол-во</th>
                <th>Стоимость</th>
                <th></th>
            </tr>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td>
                        <a href="<?php echo e(route('catalog.product', ['product' => $product->slug])); ?>">
                            <?php echo e($product->name); ?>

                        </a>
                    </td>
                    <td><?php echo e(number_format($product->price, 2, '.', '')); ?></td>
                    <td>
                        <form action="<?php echo e(route('basket.minus', ['id' => $product->id])); ?>"
                              method="post" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="m-0 p-0 border-0 bg-transparent">
                                <i class="fas fa-minus-square"></i>
                            </button>
                        </form>
                        <span class="mx-1"><?php echo e($product->pivot->quantity); ?></span>
                        <form action="<?php echo e(route('basket.plus', ['id' => $product->id])); ?>"
                              method="post" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="m-0 p-0 border-0 bg-transparent">
                                <i class="fas fa-plus-square"></i>
                            </button>
                        </form>
                    </td>
                    <td>
                        <?php echo e(number_format($product->price * $product->pivot->quantity, 2, '.', '')); ?>

                    </td>
                    <td>
                        <form action="<?php echo e(route('basket.remove', ['id' => $product->id])); ?>"
                              method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="m-0 p-0 border-0 bg-transparent">
                                <i class="fas fa-trash-alt text-danger"></i>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th colspan="4" class="text-right">Итого</th>
                <th><?php echo e(number_format($amount, 2, '.', '')); ?></th>
                <th></th>
            </tr>
        </table>
        <a href="<?php echo e(route('basket.checkout')); ?>" class="btn btn-success float-right">
            Оформить заказ
        </a>
    <?php else: ?>
        <p>Ваша корзина пуста</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', ['title' => 'Ваша корзина'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\openserver\domains\gitr-shop\resources\views/basket/index.blade.php ENDPATH**/ ?>