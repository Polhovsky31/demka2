<h4>Разделы каталога</h4>
<div id="catalog-sidebar">
    <?php echo $__env->make('layout.part.branch', ['parent' => 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH D:\OpenServer\domains\laravel-7-shop-master\resources\views/layout/part/roots.blade.php ENDPATH**/ ?>