<div class="col-md-4 mb-4">
    <div class="card list-item">
        <div class="card-header">
            <h3 class="mb-0"><?php echo e($product->name); ?></h3>
        </div>
        <div class="card-body p-0 position-relative">
            <div class="position-absolute">
                <?php if($product->new): ?>
                    <span class="badge badge-info text-white ml-1">Новинка</span>
                <?php endif; ?>
                <?php if($product->hit): ?>
                    <span class="badge badge-danger ml-1">Лидер продаж</span>
                <?php endif; ?>
                <?php if($product->sale): ?>
                    <span class="badge badge-success ml-1">Распродажа</span>
                <?php endif; ?>
            </div>
            <?php if($product->image): ?>
                <?php ($url = url('storage/catalog/product/thumb/' . $product->image)); ?>
                <img src="<?php echo e(asset('img/6ad71b6c71d1212f3222acbf9a42177a.jpeg')); ?>" class="img-fluid" alt="">
            <?php else: ?>
                <img src="https://via.placeholder.com/300x150" class="img-fluid" alt="">
            <?php endif; ?>
        </div>
        <div class="card-footer">
            <!-- Форма для добавления товара в корзину -->
            <form action="<?php echo e(route('basket.add', ['id' => $product->id])); ?>"
                  method="post" class="d-inline add-to-basket">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-success">В корзину</button>
            </form>
            <a href="<?php echo e(route('catalog.product', ['product' => $product->slug])); ?>"
               class="btn btn-dark float-right">Смотреть</a>
        </div>
    </div>
</div>
<?php /**PATH C:\OSPanel\domains\gitr-shop\resources\views/catalog/part/product.blade.php ENDPATH**/ ?>