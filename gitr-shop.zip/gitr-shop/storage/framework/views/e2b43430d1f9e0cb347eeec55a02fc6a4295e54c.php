<?php echo csrf_field(); ?>
<input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
<div class="form-group">
    <input type="text" class="form-control" name="title" placeholder="Название профиля"
           required maxlength="255" value="<?php echo e(old('title') ?? $profile->title ?? ''); ?>">
</div>
<div class="form-group">
    <input type="text" class="form-control" name="name" placeholder="Имя, Фамилия"
           required maxlength="255" value="<?php echo e(old('name') ?? $profile->name ?? ''); ?>">
</div>
<div class="form-group">
    <input type="email" class="form-control" name="email" placeholder="Адрес почты"
           required maxlength="255" value="<?php echo e(old('email') ?? $profile->email ?? ''); ?>">
</div>
<div class="form-group">
    <input type="text" class="form-control" name="phone" placeholder="Номер телефона"
           required maxlength="255" value="<?php echo e(old('phone') ?? $profile->phone ?? ''); ?>">
</div>
<div class="form-group">
    <input type="text" class="form-control" name="address" placeholder="Адрес доставки"
           required maxlength="255" value="<?php echo e(old('address') ?? $profile->address ?? ''); ?>">
</div>
<div class="form-group">
    <textarea class="form-control" name="comment" placeholder="Комментарий"
              maxlength="255" rows="2"><?php echo e(old('comment') ?? $profile->comment ?? ''); ?></textarea>
</div>
<div class="form-group">
    <button type="submit" class="btn btn-success">Сохранить</button>
</div>
<?php /**PATH D:\OpenServer\domains\laravel-7-shop-master\resources\views/user/profile/part/form.blade.php ENDPATH**/ ?>