<div class="col-md-4 mb-4">
    <div class="card list-item">
        <div class="card-header">
            <h3 class="mb-0"><?php echo e($brand->name); ?></h3>
        </div>
        <div class="card-body p-0">
            <?php if($brand->image): ?>
                <?php ($url = url('storage/catalog/brand/thumb/' . $brand->image)); ?>
                <img src="<?php echo e($url); ?>" class="img-fluid" alt="">
            <?php else: ?>
                <img src="https://via.placeholder.com/300x150" class="img-fluid" alt="">
            <?php endif; ?>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('catalog.brand', ['brand' => $brand->slug])); ?>"
               class="btn btn-dark">Товары бренда</a>
        </div>
    </div>
</div>
<?php /**PATH D:\OpenServer\domains\laravel-7-shop-master\resources\views/catalog/part/brand.blade.php ENDPATH**/ ?>