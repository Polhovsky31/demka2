<div class="col-md-4 mb-4">
    <div class="card list-item">
        <div class="card-header">
            <h3 class="mb-0"><?php echo e($category->name); ?></h3>
        </div>
        <div class="card-body p-0">
            <?php if($category->image): ?>
                
                <img src="<?php echo e(asset('img/6ad71b6c71d1212f3222acbf9a42177a.jpeg')); ?>" class="img-fluid" alt="">
            <?php else: ?>
                
            <?php endif; ?>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('catalog.category', ['category' => $category->slug])); ?>"
               class="btn btn-dark">Товары раздела</a>
        </div>
    </div>
</div>
<?php /**PATH C:\OSPanel\domains\gitr-shop\resources\views/catalog/part/category.blade.php ENDPATH**/ ?>