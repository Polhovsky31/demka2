<ul>
<?php $__currentLoopData = $items->where('parent_id', $parent); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a href="<?php echo e(route('catalog.category', ['category' => $item->slug])); ?>"><?php echo e($item->name); ?></a>
        <?php if(count($items->where('parent_id', $item->id))): ?>
            <span class="badge badge-dark">
                <i class="fa fa-plus"></i>
            </span>
            <?php echo $__env->make('layout.part.branch', ['parent' => $item->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH D:\OpenServer\domains\laravel-7-shop-master\resources\views/layout/part/branch.blade.php ENDPATH**/ ?>