<h4>Популярные бренды</h4>
<ul id="brands-popular">
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a href="<?php echo e(route('catalog.brand', ['brand' => $item->slug])); ?>"><?php echo e($item->name); ?></a>
        <span class="badge badge-dark float-right"><?php echo e($item->products_count); ?></span>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH C:\openserver\domains\gitr-shop\resources\views/layout/part/brands.blade.php ENDPATH**/ ?>