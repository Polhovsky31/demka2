<a class="nav-link <?php if($positions): ?> text-success <?php endif; ?>"
   href="<?php echo e(route('basket.index')); ?>">
    Корзина
    <?php if($positions): ?> (<?php echo e($positions); ?>) <?php endif; ?>
</a>
<?php /**PATH C:\OSPanel\domains\gitr-shop\resources\views/basket/part/basket.blade.php ENDPATH**/ ?>