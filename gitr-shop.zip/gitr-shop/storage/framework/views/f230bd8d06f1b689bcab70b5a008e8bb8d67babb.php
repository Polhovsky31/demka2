<?php $__env->startSection('content'); ?>
    <h1><?php echo e($brand->name); ?></h1>
    <p><?php echo e($brand->content); ?></p>
    <div class="bg-info p-2 mb-4">
        <!-- Фильтр для товаров бренда -->
        <form method="get"
              action="<?php echo e(route('catalog.brand', ['brand' => $brand->slug])); ?>">
            <?php echo $__env->make('catalog.part.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <a href="<?php echo e(route('catalog.brand', ['brand' => $brand->slug])); ?>"
               class="btn btn-light">Сбросить</a>
        </form>
    </div>
    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('catalog.part.product', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo e($products->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', ['title' => $brand->name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\gitr-shop\resources\views/catalog/brand.blade.php ENDPATH**/ ?>