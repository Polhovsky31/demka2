<?php $__env->startSection('content'); ?>
    <h1>Интернет-магазин</h1>
    <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem distinctio
        dolorum ducimus earum eligendi est eum eveniet excepturi exercitationem explicabo facilis
        fuga hic illum ipsam libero modi, nobis odio, officia officiis optio quae quibusdam
        reiciendis repellendus sed sunt tenetur, voluptatum. Ab adipisci aperiam esse iure neque
        quis repellendus temporibus.
    </p>

    <?php if($new->count()): ?>
        <h2>Новинки</h2>
        <div class="row">
        <?php $__currentLoopData = $new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('catalog.part.product', ['product' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <?php if($hit->count()): ?>
        <h2>Лидеры продаж</h2>
        <div class="row">
            <?php $__currentLoopData = $hit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('catalog.part.product', ['product' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <?php if($sale->count()): ?>
        <h2>Распродажа</h2>
        <div class="row">
            <?php $__currentLoopData = $sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('catalog.part.product', ['product' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\openserver\domains\gitr-shop\resources\views/index.blade.php ENDPATH**/ ?>