<?php $__currentLoopData = $pages->where('parent_id', 0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(count($pages->where('parent_id', $page->id))): ?>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown"
               role="button" data-toggle="dropdown" aria-haspopup="true"
               aria-expanded="false">
                <?php echo e($page->name); ?>

            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="<?php echo e(route('page.show', ['page' => $page->slug])); ?>">
                    <?php echo e($page->name); ?>

                </a>
                <div class="dropdown-divider"></div>
                <?php $__currentLoopData = $pages->where('parent_id', $page->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="dropdown-item" href="<?php echo e(route('page.show', ['page' => $child->slug])); ?>">
                        <?php echo e($child->name); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </li>
    <?php else: ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('page.show', ['page' => $page->slug])); ?>">
                <?php echo e($page->name); ?>

            </a>
        </li>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\OpenServer\domains\laravel-7-shop-master\resources\views/layout/part/pages.blade.php ENDPATH**/ ?>