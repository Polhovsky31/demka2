<?php $__env->startSection('content'); ?>
    <h1>Ваши заказы</h1>
    <?php if($orders->count()): ?>
        <table class="table table-bordered">
        <tr>
            <th width="2%">№</th>
            <th width="19%">Дата и время</th>
            <th width="12%">Статус</th>
            <th width="19%">Покупатель</th>
            <th width="24%">Адрес почты</th>
            <th width="22%">Номер телефона</th>
            <th width="2%"><i class="fas fa-eye"></i></th>
        </tr>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($order->id); ?></td>
                <td><?php echo e($order->created_at->format('d.m.Y H:i')); ?></td>
                <td><?php echo e($statuses[$order->status]); ?></td>
                <td><?php echo e($order->name); ?></td>
                <td><a href="mailto:<?php echo e($order->email); ?>"><?php echo e($order->email); ?></a></td>
                <td><?php echo e($order->phone); ?></td>
                <td>
                    <a href="<?php echo e(route('user.order.show', ['order' => $order->id])); ?>">
                        <i class="fas fa-eye"></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php echo e($orders->links()); ?>

    <?php else: ?>
        <p>Заказов пока нет</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', ['title' => 'Ваши заказы'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\laravel-7-shop-master\resources\views/user/order/index.blade.php ENDPATH**/ ?>