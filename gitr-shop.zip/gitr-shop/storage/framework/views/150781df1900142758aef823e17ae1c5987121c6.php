<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card mt-4 mb-4">
                <div class="card-header">
                    <h1>Страница не найдена</h1>
                </div>
                <div class="card-body">
                    <img src="<?php echo e(asset('img/404.jpg')); ?>" alt="" class="img-fluid">
                </div>
                <div class="card-footer">
                    <p class="mb-0">Запрошенная страница не найдена.</p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', ['title' => 'Страница не найдена'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\laravel-7-shop-master\resources\views/errors/404.blade.php ENDPATH**/ ?>