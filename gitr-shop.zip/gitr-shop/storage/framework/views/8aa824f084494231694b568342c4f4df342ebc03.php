<?php ($level++); ?>
<?php $__currentLoopData = $items->where('parent_id', $parent); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>
            <?php if($level): ?>
                <?php echo e(str_repeat('—', $level)); ?>

            <?php endif; ?>
            <a href="<?php echo e(route('admin.category.show', ['category' => $item->id])); ?>"
               style="font-weight:<?php if($level): ?> normal <?php else: ?> bold <?php endif; ?>">
                <?php echo e($item->name); ?>

            </a>
        </td>
        <td><?php echo e(iconv_substr($item->content, 0, 150)); ?></td>
        <td>
            <a href="<?php echo e(route('admin.category.edit', ['category' => $item->id])); ?>">
                <i class="far fa-edit"></i>
            </a>
        </td>
        <td>
            <form action="<?php echo e(route('admin.category.destroy', ['category' => $item->id])); ?>"
                  method="post" onsubmit="return confirm('Удалить эту категорию?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="m-0 p-0 border-0 bg-transparent">
                    <i class="far fa-trash-alt text-danger"></i>
                </button>
            </form>
        </td>
    </tr>
    <?php if(count($items->where('parent_id', $parent))): ?>
        <?php echo $__env->make('admin.category.part.tree', ['level' => $level, 'parent' => $item->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\OSPanel\domains\gitr-shop\resources\views/admin/category/part/tree.blade.php ENDPATH**/ ?>