<?php $__env->startSection('content'); ?>
    <div><p>АМЛЕТ</p></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', ['title' => $page->name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\gitr-shop\resources\views/page/show.blade.php ENDPATH**/ ?>