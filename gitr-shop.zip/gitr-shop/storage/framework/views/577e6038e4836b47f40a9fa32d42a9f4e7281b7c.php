<?php $__env->startSection('content'); ?>
    <h1>Просмотр товара</h1>
    <div class="row">
        <div class="col-md-6">
            <p><strong>Название:</strong> <?php echo e($product->name); ?></p>
            <p><strong>ЧПУ (англ):</strong> <?php echo e($product->slug); ?></p>
            <p><strong>Бренд:</strong> <?php echo e($product->brand->name); ?></p>
            <p><strong>Категория:</strong> <?php echo e($product->category->name); ?></p>
            <p><strong>Новинка:</strong> <?php if($product->new): ?> да <?php else: ?> нет <?php endif; ?></p>
            <p><strong>Лидер продаж:</strong> <?php if($product->hit): ?> да <?php else: ?> нет <?php endif; ?></p>
            <p><strong>Распродажа:</strong> <?php if($product->sale): ?> да <?php else: ?> нет <?php endif; ?></p>
        </div>
        <div class="col-md-6">
            <?php
                if ($product->image) {
                    $url = url('storage/catalog/product/image/' . $product->image);
                } else {
                    $url = url('storage/catalog/product/image/default.jpg');
                }
            ?>
            <img src="<?php echo e(asset('img/9e1e3bf9c49924a6f73cf10b6f0d3a91.jpeg')); ?>" alt="" class="img-fluid">
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <p><strong>Описание</strong></p>
            <?php if(isset($product->content)): ?>
                <p><?php echo e($product->content); ?></p>
            <?php else: ?>
                <p>Описание отсутствует</p>
            <?php endif; ?>
            <a href="<?php echo e(route('admin.product.edit', ['product' => $product->id])); ?>"
               class="btn btn-success">
                Редактировать товар
            </a>
            <form method="post" class="d-inline" onsubmit="return confirm('Удалить этот товар?')"
                  action="<?php echo e(route('admin.product.destroy', ['product' => $product->id])); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">
                    Удалить товар
                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', ['title' => 'Просмотр товара'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\gitr-shop\resources\views/admin/product/show.blade.php ENDPATH**/ ?>