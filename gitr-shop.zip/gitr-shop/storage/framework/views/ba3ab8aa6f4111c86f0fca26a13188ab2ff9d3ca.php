<?php $__env->startSection('content'); ?>
    <h1>Личный кабинет</h1>
    <p>Добро пожаловать, <?php echo e(auth()->user()->name); ?>!</p>
    <p>Это личный кабинет постоянного покупателя нашего интернет-магазина.</p>
    <ul>
        <li><a href="<?php echo e(route('user.profile.index')); ?>">Ваши профили</a></li>
        <li><a href="<?php echo e(route('user.order.index')); ?>">Ваши заказы</a></li>
    </ul>
    <form action="<?php echo e(route('user.logout')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-primary">Выйти</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', ['title' => 'Личный кабинет'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\gitr-shop\resources\views/user/index.blade.php ENDPATH**/ ?>