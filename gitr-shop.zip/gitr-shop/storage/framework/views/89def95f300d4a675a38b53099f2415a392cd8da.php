<?php $__env->startSection('content'); ?>
    <h1>Поиск по каталогу</h1>
    <p>Поисковый запрос: <?php echo e($search ?? 'пусто'); ?></p>
    <?php if(count($products)): ?>
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('catalog.part.product', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo e($products->links()); ?>

    <?php else: ?>
        <p>По вашему запросу ничего не найдено</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', ['title' => 'Поиск по каталогу'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\laravel-7-shop-master\resources\views/catalog/search.blade.php ENDPATH**/ ?>