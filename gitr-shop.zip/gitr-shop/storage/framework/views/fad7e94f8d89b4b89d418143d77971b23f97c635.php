<?php $__env->startSection('content'); ?>
    <h1>Все категории</h1>
    <a href="<?php echo e(route('admin.category.create')); ?>" class="btn btn-success mb-4">
        Создать категорию
    </a>
    <table class="table table-bordered">
        <tr>
            <th width="30%">Наименование</th>
            <th width="65%">Описание</th>
            <th><i class="fas fa-edit"></i></th>
            <th><i class="fas fa-trash-alt"></i></th>
        </tr>
        <?php echo $__env->make('admin.category.part.tree', ['level' => -1, 'parent' => 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', ['title' => 'Все категории каталога'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\gitr-shop\resources\views/admin/category/index.blade.php ENDPATH**/ ?>